import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

plugins {
    kotlin("jvm") version "1.9.0"
    application
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testImplementation(kotlin("test"))

    // Library for CSV
    implementation("com.opencsv:opencsv:3.7") //> have security vulnerabilities

    // Library for JSON
    implementation("com.google.code.gson:gson:2.8.9")

    // Libraries needed for XML
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.3.0")
    implementation("javax.xml.bind:jaxb-api:2.3.1")
    implementation("org.glassfish.jaxb:jaxb-runtime:2.3.3")
}


tasks.test {
    useJUnitPlatform()
}

tasks.withType<KotlinCompile> {
    kotlinOptions.jvmTarget = "1.8"
}

application {
    mainClass.set("MainKt")
}