/**
 * Extension functions for [MutableList] of [BankCustomer] to perform various operations.
 */
object MyMutableExtensions {

    /**
     * Removes duplicate [BankCustomer] objects based on their account numbers.
     *
     * @return A new [MutableList] containing distinct [BankCustomer] objects based on account numbers.
     */
    fun MutableList<BankCustomer>.removeDuplicatesByAccountNumber() : MutableList<BankCustomer>{
        return this.distinctBy { it.account }.toMutableList()
    }

    /**
     * Adds a [BankCustomer] to the [MutableList] only if a customer with the same account number
     * does not already exist in the list.
     *
     * @param customer The [BankCustomer] to be added.
     */
    fun MutableList<BankCustomer>.addIfNotDuplicate(customer: BankCustomer) {
        if (this.all { it.account != customer.account }) {
            this.add(customer)
        }
    }

    /**
     * Extension function to remove a [BankCustomer] from the [MutableList] based on the account number.
     *
     * @param accountNumber The account number of the customer to be removed.
     */
    fun MutableList<BankCustomer>.removeByAccountNumber(accountNumber: String?) {
        val customerToRemove = this.find { it.account == accountNumber }

        if (customerToRemove != null) {
            this.remove(customerToRemove)
            println("Customer with account number $accountNumber removed successfully.")
        } else {
            println("No customer found with account number $accountNumber. No customer removed.")
        }
    }

    /**
     * Prints details of all [BankCustomer] objects in the [MutableList].
     */
    fun MutableList<BankCustomer>.printAll() {
        this.forEach { customer -> customer.printMe() }
    }

    /**
     * Prints details of [customer] object in the [MutableList] of [BankCustomer]s .
     */
    fun MutableList<BankCustomer>.printOne(acc:String) {
        for ((index, customer) in this.withIndex()) {
            if (customer.account == acc) {
                customer.printMe()
            }
            else {
                println("Error: ${acc} not found")
            }
        }
    }
}