import MyMutableExtensions.addIfNotDuplicate
import MyMutableExtensions.printAll
import MyMutableExtensions.removeByAccountNumber
import MyMutableExtensions.removeDuplicatesByAccountNumber

import DataUtils.loadCustomersFromCSV
import DataUtils.writeCustomersToCSV
import DataUtils.loadCustomersFromJSON
import DataUtils.writeCustomersToJSON
import DataUtils.loadCustomersFromXml
import DataUtils.writeCustomersToXml

fun main(args: Array<String>) {

    // Create a new BankCustomer
    val newCustomer = BankCustomer(
        "Jane",
        "Doe",
        5678,
        "987654321",
        "123456"
    )
    val customer = BankCustomer(
        "Marshall",
        "Mathers",
        5678,
        "123456789",
        "123456"
    )

    //CSV
    var csvExistingCustomers = loadCustomersFromCSV("customers.csv")
    csvExistingCustomers = csvExistingCustomers.removeDuplicatesByAccountNumber()

    csvExistingCustomers.addIfNotDuplicate(newCustomer)
    csvExistingCustomers.addIfNotDuplicate(customer)

    println("All Customers:")
    println(csvExistingCustomers) // Note how this line prints the object reference
    csvExistingCustomers.printAll()

    writeCustomersToCSV(csvExistingCustomers, "customers.csv")


    //JSON
    var jsonExistingCustomers = loadCustomersFromJSON("customers.json")
    jsonExistingCustomers = jsonExistingCustomers.removeDuplicatesByAccountNumber()

    jsonExistingCustomers.addIfNotDuplicate(newCustomer)
    jsonExistingCustomers.addIfNotDuplicate(customer)

    writeCustomersToJSON(jsonExistingCustomers, "customers.json")

    // XML
    var existingCustomers = loadCustomersFromXml("customers.xml")
    existingCustomers = existingCustomers.removeDuplicatesByAccountNumber()

    // Add the new customer to the existing list
    existingCustomers.addIfNotDuplicate(newCustomer)
    existingCustomers.addIfNotDuplicate(customer)

    println("All Customers:")
    existingCustomers.printAll()

    // Write the updated list back to XML
    writeCustomersToXml(existingCustomers, "customers.xml")

    // remove selected customer from the List and then from the XML
    existingCustomers.removeByAccountNumber(customer.account)

    println("All Customers:")
    existingCustomers.printAll()
    writeCustomersToXml(existingCustomers, "customers.xml")
}