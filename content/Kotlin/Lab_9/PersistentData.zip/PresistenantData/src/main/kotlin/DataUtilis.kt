import com.opencsv.CSVReaderBuilder
import com.opencsv.CSVWriter
import java.io.File

import com.google.gson.Gson

import javax.xml.bind.JAXBContext
import javax.xml.bind.Marshaller
import javax.xml.bind.annotation.XmlElement
import javax.xml.bind.annotation.XmlRootElement
import javax.xml.bind.annotation.XmlAccessType
import javax.xml.bind.annotation.XmlAccessorType

/**
 * Utility object for handling data operations, including loading and writing data in JSON, CSV, and XML formats.
 */
object DataUtils {

    /**
     * Loads a list of [BankCustomer] objects from a CSV file.
     *
     * @param filePath The path to the CSV file.
     * @return A [MutableList] of [BankCustomer] objects loaded from the CSV file.
     */
    fun loadCustomersFromCSV(filePath: String): MutableList<BankCustomer> {
        val file = File(filePath)
        makeFile(filePath)
        if (file.exists()) {
            file.reader().use { reader ->
                try {
                    val csvReader = CSVReaderBuilder(reader).build()
                    val lines = csvReader.readAll()
                    val customerList = mutableListOf<BankCustomer>()

                    for (line in lines) {
                        // Create BankCustomer objects from CSV lines
                        val customer = BankCustomer(line[0], line[1], line[2].toInt(), line[3], line[4])
                        customerList.add(customer)
                    }
                    return customerList
                } catch (e: Exception) {
                    // Handle exceptions during CSV parsing
                    return mutableListOf()
                }
            }
        } else {
            return mutableListOf()
        }
    }

    /**
     * Writes a list of [BankCustomer] objects to a CSV file.
     *
     * @param customerList The list of [BankCustomer] objects to be written to the CSV file.
     * @param filePath The path to the CSV file.
     */
    fun writeCustomersToCSV(customerList: List<BankCustomer>, filePath: String) {
        val file = File(filePath)
        makeFile(filePath)
        if (file.exists()) {
            file.writer().use { writer ->
                val csvWriter = CSVWriter(writer)

                for (customer in customerList) {
                    // Convert BankCustomer objects to CSV records
                    val record = arrayOf(
                        customer.firstName.orEmpty(),
                        customer.lastName.orEmpty(),
                        customer.pin?.toString() ?: "",
                        customer.account.orEmpty(),
                        customer.sortCode.orEmpty()
                    )
                    csvWriter.writeNext(record)
                }

                csvWriter.close()
            }
        } else {
            println("File doesn't exist")
        }
    }

    /**
     * Loads a list of [BankCustomer] objects from a JSON file.
     *
     * @param filePath The path to the JSON file.
     * @return A [MutableList] of [BankCustomer] objects loaded from the JSON file.
     */
    fun loadCustomersFromJSON(filePath: String): MutableList<BankCustomer> {
        val gson = Gson()

        val file = File(filePath)
        if (file.exists()) {
            file.reader().use { reader ->
                try {
                    // Deserialize JSON into a list of BankCustomer objects
                    return gson.fromJson(reader, Array<BankCustomer>::class.java).toMutableList()
                } catch (e: Exception) {
                    // Handle exceptions during JSON parsing
                    return mutableListOf()
                }
            }
        } else {
            // If the file doesn't exist, return an empty list
            return mutableListOf()
        }
    }

    /**
     * Writes a list of [BankCustomer] objects to a JSON file.
     *
     * @param customerList The list of [BankCustomer] objects to be written to the JSON file.
     * @param filePath The path to the JSON file.
     */
    fun writeCustomersToJSON(customerList: List<BankCustomer>, filePath: String) {
        val gson = Gson()
        val file = File(filePath)
        if (file.exists()) {
            // Convert the updated list to a formatted JSON string
            // Convert the list to a JSON string with each property on a new line
            val formattedJson = gson.toJson(customerList)
                .replace("[", "[\n\t")
                .replace(",", ",\n\t\t")
                .replace("{", "{\n\t\t")
                .replace("}", "\n\t}")
                .replace("},\n\t\t{", "},\n\t{")
                .replace("]", "\n]")

            // Write the formatted JSON to the file (overwrite)
            file.writer().use { writer ->
                writer.write(formattedJson)
            }
        } else {
            println("File doesn't exist")
        }
    }

    /**
     * Loads a list of [BankCustomer] objects from an XML file.
     *
     * @param filePath The path to the XML file.
     * @return A [MutableList] of [BankCustomer] objects.
     */
    fun loadCustomersFromXml(filePath: String): MutableList<BankCustomer> {
        try {
            val context = JAXBContext.newInstance(CustomersWrapper::class.java)
            val unmarshaller = context.createUnmarshaller()
            val wrapper = unmarshaller.unmarshal(File(filePath)) as CustomersWrapper
            return wrapper.customerList.toMutableList()
        } catch (e: Exception) {
            // Handle exceptions during XML parsing
            e.printStackTrace()
        }
        return mutableListOf()
    }

    /**
     * Writes a list of [BankCustomer] objects to an XML file.
     *
     * @param customers The list of [BankCustomer] objects to write.
     * @param filePath The path to the XML file.
     * @throws Exception to log
     */
    fun writeCustomersToXml(customers: List<BankCustomer>, filePath: String) {
        try {
            val context = JAXBContext.newInstance(CustomersWrapper::class.java)
            val marshaller = context.createMarshaller()
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true)

            val wrapper = CustomersWrapper()
            wrapper.customerList = ArrayList(customers)

            marshaller.marshal(wrapper, File(filePath))
        } catch (e: Exception) {
            // Handle exceptions during XML writing
            e.printStackTrace()
        }
    }

    /**
     * Creates a new file at the specified [filePath].
     *
     * @param filePath The path to the file to be created.
     */
    fun makeFile(filePath: String) {
        val file = File(filePath)

        try {
            if (file.createNewFile()) {
                println("File created successfully.")
            } else {
                println("File already exists.")
            }
        } catch (e: Exception) {
            // Handle exceptions during file creation
            println("An error occurred while creating the file: ${e.message}")
        }
    }
}

/**
 * Wrapper class for marshalling and unmarshalling a list of [BankCustomer] objects.
 */
@XmlRootElement(name = "customersWrapper")
@XmlAccessorType(XmlAccessType.FIELD)
class CustomersWrapper {
    @XmlElement(name = "customer")
    var customerList: List<BankCustomer> = ArrayList()
}