import javax.xml.bind.annotation.XmlRootElement
/**
 * Represents a bank customer with basic information such as first name, last name, PIN, account number,
 * and sort code.
 *
 * @property firstName The first name of the customer.
 * @property lastName The last name of the customer.
 * @property pin The PIN (Personal Identification Number) of the customer.
 * @property account The account number of the customer.
 * @property sortCode The sort code associated with the customer's account.
 *
 * @constructor Creates a new [BankCustomer] with the specified details.
 * @param fn The first name of the customer.
 * @param ln The last name of the customer.
 * @param p The PIN (Personal Identification Number) of the customer.
 * @param acc The account number of the customer.
 * @param sc The sort code associated with the customer's account.
 */
@XmlRootElement(name = "customer")
class BankCustomer {
    var firstName: String? = null
    var lastName: String? = null
    var pin: Int? = null
    var account: String? = null
    var sortCode: String? = null

    /**
     * Default constructor for [BankCustomer].
     */
    constructor()

    /**
     * Creates a new [BankCustomer] with the specified details.
     *
     * @param fn The first name of the customer.
     * @param ln The last name of the customer.
     * @param p The PIN (Personal Identification Number) of the customer.
     * @param acc The account number of the customer.
     * @param sc The sort code associated with the customer's account.
     */
    constructor(fn: String, ln: String, p: Int, acc: String, sc: String) {
        firstName = fn
        lastName = ln
        pin = p
        account = acc
        sortCode = sc
    }

    /**
     * Prints the details of the customer, including name, PIN, account number, and sort code.
     */
    fun printMe() {
        println(
            "Customer:\n\tName: ${this.firstName} ${this.lastName}\n\tPin: ${this.pin}\n\t" +
                    "Account: ${this.account}\n\tSort Code:${this.sortCode}"
        )
    }
}